Windows configuration
1) Install the NVIDIA CUDA Toolkit, required for projects.
2) Install uv by following the official instructions for the standalone installer at: https://docs.astral.sh/uv/getting-started/installation/#standalone-installer.
3) Ensure the project directory (project_folder) contains the pyproject.toml configuration file.
4) Open a Command Prompt (CMD), navigate to the project directory, and run "uv venv" command to create the virtual environment.
5) In Visual Studio Code, press Ctrl + Shift + P, choose the "Python: Select Interpreter" option, and then select the path to the interpreter from the virtual environment: project_folder\.venv\Scripts\python.exe.