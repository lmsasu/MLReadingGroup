#
#
#
# #This file can be run independently to get familiar with 'pos' and 'faces'.
#
#
#

import torch
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from torch_geometric.data import Data
from torch_geometric.datasets import GeometricShapes
from torch_geometric.transforms import SamplePoints

# Define the 3D coordinates of vertices (pos)
pos = torch.tensor([
    [0, 0, 0],  # Vertex 0
    [1, 0, 0],  # Vertex 1
    [1, 1, 0],  # Vertex 2
    [0, 1, 0],  # Vertex 3
    [0, 0, 1],  # Vertex 4
    [1, 0, 1],  # Vertex 5
    [1, 1, 1],  # Vertex 6
    [0, 1, 1],  # Vertex 7
], dtype=torch.float)

# Define the faces of the cube (face)
face = torch.tensor([
    [0, 1, 2],  # Face 0: vertices 0, 1, 2
    [0, 2, 3],  # Face 1: vertices 0, 2, 3
    [4, 5, 6],  # Face 2: vertices 4, 5, 6
    [4, 6, 7],  # Face 3: vertices 4, 6, 7
    [0, 1, 5],  # Face 4: vertices 0, 1, 5
    [0, 5, 4],  # Face 5: vertices 0, 5, 4
    [2, 3, 7],  # Face 6: vertices 2, 3, 7
    [2, 7, 6],  # Face 7: vertices 2, 7, 6
    [1, 2, 6],  # Face 8: vertices 1, 2, 6
    [1, 6, 5],  # Face 9: vertices 1, 6, 5
    [0, 3, 7],  # Face 10: vertices 0, 3, 7
    [0, 7, 4],  # Face 11: vertices 0, 7, 4
], dtype=torch.long).t()  # Transpose to have one column per face

# Visualize the cube
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot vertices
ax.scatter(pos[:, 0], pos[:, 1], pos[:, 2], c='r', marker='o')

# Plot faces
for i in range(face.size(1)):
    face_vertices = face[:, i]
    face_vertices = torch.cat([face_vertices, face_vertices[0].view(1)])  # Close the loop
    ax.plot(pos[face_vertices, 0], pos[face_vertices, 1], pos[face_vertices, 2], c='b')

    # Annotate the face with its number
    face_center = pos[face_vertices].mean(dim=0)
    ax.text(face_center[0], face_center[1], face_center[2], f'Face {i}', color='black')

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('3D Cube Mesh')


# test_dataset = GeometricShapes(root='data/GeometricShapes', train=True,
#                                transform=SamplePoints(128))
# Create a PyTorch Geometric Data object

data = Data(pos=pos, face=face)

# Apply SamplePoints transform
num_samples = 1000  # You can adjust the number of sampled points
transform = SamplePoints(num_samples)
data = transform(data)

# Access the sampled points
sampled_points = data.pos

# Print the sampled points
print(sampled_points)
plt.show()
