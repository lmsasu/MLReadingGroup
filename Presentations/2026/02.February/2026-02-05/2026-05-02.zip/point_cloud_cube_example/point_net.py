import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "../"))


from torch.nn import Linear

from point_net_layer import PointNetLayer
import torch
import torch.nn.functional as F
from torch_cluster import knn_graph
from torch_geometric.nn import global_max_pool, GCNConv
from torch_geometric.datasets import GeometricShapes

from draw import visualize_points


class PointNet(torch.nn.Module):
    def __init__(self):
        super().__init__()
        dataset = GeometricShapes(root='data/GeometricShapes')
        torch.manual_seed(12345)
        self.conv1 = PointNetLayer(3, 32)
        self.conv2 = PointNetLayer(32, 32)
        self.classifier = Linear(32, dataset.num_classes)

    def forward(self, pos, batch):
        # Compute the kNN graph:
        # Here, we need to pass the batch vector to the function call in order
        # to prevent creating edges between points of different examples.
        # We also add `loop=True` which will add self-loops to the graph in
        # order to preserve central point information.
        edge_index = knn_graph(pos, k=2, batch=batch, loop=True)  # ce e edge index vizualizare


        visualize_points(pos, edge_index=edge_index)
        print("POS is: ")
        print(pos)

        print("Edge index is ")
        print(edge_index)
        exit(0)


        # 3. Start bipartite message passing.
        h = self.conv1(h=pos, pos=pos, edge_index=edge_index)
        h = h.relu()
        h = self.conv2(h=h, pos=pos, edge_index=edge_index)
        h = h.relu()

        # 4. Global Pooling.
        h = global_max_pool(h, batch)  # [num_examples, hidden_channels]   # ce este asta???

        # 5. Classifier.
        return self.classifier(h)