#
#
#
# Run this file by itself to familiarize yourself with the local test data.
#
#
#

import os
import torch
from torch_geometric.datasets import GeometricShapes
from torchview import draw_graph

os.environ['TORCH'] = torch.__version__
print(torch.__version__)

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def visualize_mesh(pos, face):
    fig = plt.figure()
    ax = fig.add_subplot(projection = '3d')
    ax.axes.xaxis.set_ticklabels([])
    ax.axes.yaxis.set_ticklabels([])
    ax.axes.zaxis.set_ticklabels([])
    ax.plot_trisurf(pos[:, 0], pos[:, 1], pos[:, 2], triangles=face.t(), antialiased=False)
    plt.show()




import torch
from torch_geometric.data import Data


x = torch.tensor([[2,1], [5,6], [3,7], [12,0]], dtype=torch.float)
y = torch.tensor([0, 1, 0, 1], dtype=torch.float)

edge_index = torch.tensor([[0, 2, 1, 0, 3],
                           [3, 1, 0, 1, 2]], dtype=torch.long)


data = Data(x=x, y=y, edge_index=edge_index)
print(data)

test_dataset = GeometricShapes(root='C:\\Users\\ioch261647\\PycharmProjects\\point_cloud_project\\test_data_folder', train=False)

#
#
# The value '13' is the index of the shape to display. Modify it (e.g., to a value between 0 and 40) to visualize a different shape.
#
#
#

visualize_mesh(test_dataset.get(13).pos, test_dataset.get(13).face)
