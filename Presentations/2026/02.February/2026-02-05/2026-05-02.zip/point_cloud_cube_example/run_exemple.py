from IPython.core.display_functions import display
from torch_geometric.data import Data, Batch

from point_net import PointNet
import torch
from torch_geometric.datasets import GeometricShapes
from torch_geometric.transforms import SamplePoints
import os

from draw import visualize_mesh, visualize_points, draw_model_graph



os.environ['TORCH'] = torch.__version__
print(torch.__version__)



# Define the 3D coordinates of vertices (pos)
pos = torch.tensor([
    [0, 0, 0],  # Vertex 0
    [1, 0, 0],  # Vertex 1
    [1, 1, 0],  # Vertex 2
    [0, 1, 0],  # Vertex 3
    [0, 0, 1],  # Vertex 4
    [1, 0, 1],  # Vertex 5
    [1, 1, 1],  # Vertex 6
    [0, 1, 1],  # Vertex 7
], dtype=torch.float)

# Define the faces of the cube (face)
face = torch.tensor([
    [0, 1, 2],  # Face 0: vertices 0, 1, 2
    [0, 2, 3],  # Face 1: vertices 0, 2, 3
    [4, 5, 6],  # Face 2: vertices 4, 5, 6
    [4, 6, 7],  # Face 3: vertices 4, 6, 7
    [0, 1, 5],  # Face 4: vertices 0, 1, 5
    [0, 5, 4],  # Face 5: vertices 0, 5, 4
    [2, 3, 7],  # Face 6: vertices 2, 3, 7
    [2, 7, 6],  # Face 7: vertices 2, 7, 6
    [1, 2, 6],  # Face 8: vertices 1, 2, 6
    [1, 6, 5],  # Face 9: vertices 1, 6, 5
    [0, 3, 7],  # Face 10: vertices 0, 3, 7
    [0, 7, 4],  # Face 11: vertices 0, 7, 4
], dtype=torch.long).t()  # Transpose to have one column per face

# Create a constant y value (assuming you want to set y=1 for all nodes)
y_value = 1
y = torch.full((pos.size(0),), y_value, dtype=torch.float)

from IPython.display import Javascript  # Restrict height of output cell.

display(Javascript('''google.colab.output.setIframeHeight(0, true, {maxHeight: 300})'''))

from torch_geometric.loader import DataLoader


visualize_mesh(pos, face)

data = Data(pos=pos, face=face, y=y)
train_dataset = []
for i in range(1):
    data = Data(pos=pos, face=face, y=y)
    train_dataset.append(data)


# Apply SamplePoints transform
num_samples = 16  # You can adjust the number of sampled points
transform = SamplePoints(num_samples)

train_dataset = [transform(data) for data in train_dataset]


print("edge index:")
visualize_points(train_dataset[0].pos, train_dataset[0].edge_index)

# train_dataset1 = GeometricShapes(root='data/GeometricShapes', train=True,
#                                 transform=SamplePoints(128))

train_loader = DataLoader(train_dataset, batch_size=10, shuffle=True)

for batch in train_loader:
    print("Batch is")
    print(batch)


# train_loader = DataLoader(train_dataset, batch_size=1, shuffle=True)
# test_loader = DataLoader(test_dataset, batch_size=10)

model = PointNet()

optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
criterion = torch.nn.CrossEntropyLoss()  # Define loss criterion.

def train(model, optimizer, loader):
    model.train()
    total_loss = 0
    for data in loader:
        # Ensure that 'batch' attribute is present
        # if 'batch' not in data:
        #     data.batch = torch.zeros(data.pos.size(0), dtype=torch.long)
        #     # Ensure that 'y' attribute is present
        # if 'y' not in data:
        #     y_value = 1
        #     data.y = torch.full((pos.size(0),), y_value, dtype=torch.float)


        optimizer.zero_grad()  # Clear gradients.
        logits = model(data.pos, data.batch)  # Forward pass.
        print(data.pos)
        target_y = torch.full_like(logits.argmax(dim=-1), fill_value=1, dtype=torch.long)
        loss = criterion(logits, target_y)  # Loss computation.
        loss.backward()  # Backward pass.
        optimizer.step()  # Update model parameters.
        total_loss += loss.item() * data.num_graphs    #vizualizare data si vizualizare data.y

    return total_loss / len(train_loader.dataset)


@torch.no_grad()
def test(model, loader):
    model.eval()

    total_correct = 0
    for data in loader:
        logits = model(data.pos, data.batch)
        pred = logits.argmax(dim=-1)
        total_correct += int((pred == data.y).sum())

    return total_correct / len(loader.dataset)


for epoch in range(1, 51):
    print("start training")
    loss = train(model, optimizer, train_loader)
    # test_acc = test(model, test_loader)
    # print(f'Epoch: {epoch:02d}, Loss: {loss:.4f}, Test Accuracy: {test_acc:.4f}')
