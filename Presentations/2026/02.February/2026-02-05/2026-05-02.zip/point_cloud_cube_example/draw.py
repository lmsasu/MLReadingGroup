import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "../"))

# Install required packages.
import os
import torch
from torch_geometric.datasets import GeometricShapes
from torchview import draw_graph

os.environ['TORCH'] = torch.__version__
print(torch.__version__)

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np


def visualize_mesh(pos, face):
    # Convert list to NumPy array
    pos_np = np.array(pos)
    face_np = np.array(face)

    # If face_np shape is (3, n_triangles), transpose it to (n_triangles, 3)
    if face_np.shape[0] == 3 and len(face_np.shape) == 2:
        face_np = face_np.T # Use .T for NumPy transpose

    fig = plt.figure()
    ax = fig.add_subplot(projection='3d')
    ax.axes.xaxis.set_ticklabels([])
    ax.axes.yaxis.set_ticklabels([])
    ax.axes.zaxis.set_ticklabels([])
    
    # Use the NumPy array
    ax.plot_trisurf(pos_np[:, 0], pos_np[:, 1], pos_np[:, 2], triangles=face_np, antialiased=False)
    plt.show()
    
#
def visualize_points(pos, edge_index=None, index=None):
    fig = plt.figure(figsize=(4, 4))
    if edge_index is not None:
        for (src, dst) in edge_index.t().tolist():
             src = pos[src].tolist()
             dst = pos[dst].tolist()
             plt.plot([src[0], dst[0]], [src[1], dst[1]], linewidth=1, color='black')
    if index is None:
        plt.scatter(pos[:, 0], pos[:, 1], s=50, zorder=1000)
    else:
       mask = torch.zeros(pos.size(0), dtype=torch.bool)
       mask[index] = True
       plt.scatter(pos[~mask, 0], pos[~mask, 1], s=50, color='lightgray', zorder=1000)
       plt.scatter(pos[mask, 0], pos[mask, 1], s=50, zorder=1000)
    plt.axis('off')
    plt.show()

def draw_model_graph(model, batch_size):
    x = torch.randn((10, 3, 161, 161))

    model_graph  = draw_graph(model, input_data = (1,3,32,32), directory = '.', save_graph = True)
    model_graph.visual_graph

