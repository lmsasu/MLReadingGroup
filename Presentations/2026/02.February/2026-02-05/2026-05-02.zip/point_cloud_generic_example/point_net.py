import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "../../../"))

from torch import Tensor
import torch
from torch_geometric.nn import global_max_pool
from torch.nn import Linear

from point_cloud_generic_example.point_net_layer import PointNetLayer
from torch_geometric.datasets import GeometricShapes

class PointNet(torch.nn.Module):
    def __init__(self):
        super().__init__()

        self.conv1 = PointNetLayer(3, 32)
        self.conv2 = PointNetLayer(32, 32)
        dataset = GeometricShapes(root='data/GeometricShapes')
        self.classifier = Linear(32, dataset.num_classes)

    def forward(self,
        pos: Tensor,
        edge_index: Tensor,
        batch: Tensor,
    ) -> Tensor:

        # Perform two-layers of message passing:
        h = self.conv1(h=pos, pos=pos, edge_index=edge_index)
        h = h.relu()
        h = self.conv2(h=h, pos=pos, edge_index=edge_index)
        h = h.relu()

        # Global Pooling:
        h = global_max_pool(h, batch)  # [num_examples, hidden_channels]

        # Classifier:
        return self.classifier(h)


model = PointNet()